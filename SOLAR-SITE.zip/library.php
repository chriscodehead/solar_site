<?php
ob_start();
session_start();

$siteYear = date('Y');
$dummyEmail = 'pristinerenewablesolutions@gmail.com';
$companyNumber = '12850124';
$domain = 'pristinerenewablesolutions.com';
$siteLink = 'https://' . $domain . '/';
$siteRegister = 'https://' . $domain . '/accounts/register';
$siteLogin = 'https://' . $domain . '/accounts/login';
$site = 'https://' . $domain;
$siteName = 'Pristine Renewable Solutions LTD';
$siteEmail = "support@" . $domain;
$siteEmail2 = "support@" . $domain;
$sitePhone = '+1 (000) 000-0000';
$sitePhone2 = '+1 (000) 000-0000';
$siteAddress = '3891 Ranchview Dr. Richardson,
California 62639';
$siteAddress2 = '';
$site_whatsapp_num = '+1 (000) 000-0000';
$siteWhatsApp = 'https://api.whatsapp.com/send?phone=' . $site_whatsapp_num . '&text=Hi ' . $siteName . ', my name is ...! I want to make enquires about your products...';
$siteDomain = $domain;
$siteWhatsAppLink = 'https://api.whatsapp.com/send?phone=' . $site_whatsapp_num . '&text=';
$siteTelegram = 'https://telegram.com/';
$siteTwitter = 'https://twitter.com/';
$siteFacebook = 'https://facebook.com/';
$siteLinkedin = 'https://linkedin.com/';
$siteInstagram = 'https://instagram.com/';
$siteYoutube = 'https://youtube.com/';
