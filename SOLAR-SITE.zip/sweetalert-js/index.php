<?php
 header("location:../");
 ?>